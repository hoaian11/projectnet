﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Webthucannhanh.Datas;
using Webthucannhanh.Models;

namespace Webthucannhanh.Controllers;

public class FoodController : Controller
{
    private readonly FoodOrderingDbContext _context;

    public FoodController(FoodOrderingDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var foodItems = _context.FoodItems.ToList();
        return View(foodItems);
    }

    public IActionResult Details(int id)
    {
        var foodItem = _context.FoodItems.Find(id);
        if (foodItem == null)
        {
            return NotFound();
        }
        return View(foodItem);
    }
}

public class OrderController : Controller
{
    private readonly FoodOrderingDbContext _context;

    public OrderController(FoodOrderingDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public IActionResult Create(int customerId, List<int> foodItemIds)
    {
        var order = new Order // corrected from Oder
        {
            CustomerId = customerId,
            OrderDate = DateTime.Now,
            Status = "Processing"
        };
        _context.Orders.Add(order);
        _context.SaveChanges();

        foreach (var foodItemId in foodItemIds)
        {
            var orderDetail = new OrderDetail // corrected from OrderDetail
            {
                OrderId = order.OrderId,
                FoodItemId = foodItemId,
                Quantity = 1,
                Price = _context.FoodItems.Find(foodItemId).Price
            };

            _context.OrderDetails.Add(orderDetail);
        }

        _context.SaveChanges();
        return RedirectToAction("Details", new { id = order.OrderId });
    }

    public ActionResult Details(int id)
    {
        var order = _context.Orders
            .Include(o => o.OrderDetails)
        .ThenInclude(od => od.FoodItem)
        .FirstOrDefault(o => o.OrderId == id);

        if (order == null)
        {
            return NotFound();
        }

        return View(order);
    }
}


