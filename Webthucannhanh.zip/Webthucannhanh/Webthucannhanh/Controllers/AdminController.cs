﻿using System;
using Microsoft.AspNetCore.Mvc;
using Webthucannhanh.Datas;

namespace Webthucannhanh.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminsController : ControllerBase
    {
        private readonly FoodOrderingDbContext _context;

        public AdminsController(FoodOrderingDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var admins = _context.Admins.ToList();
            return Ok(admins);
        }

        [HttpPost]
        public IActionResult Create(Admin admin)
        {
            _context.Admins.Add(admin);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetById), new { id = admin.AdminId }, admin);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null)
            {
                return NotFound();
            }
            return Ok(admin);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null)
            {
                return NotFound();
            }

            _context.Admins.Remove(admin);
            _context.SaveChanges();
            return NoContent();
        }
    }

}



