﻿using System;
namespace Webthucannhanh.Controllers
{
	public class FoodItemController
	{
		public FoodItemController()
		{
		}
	}
}

