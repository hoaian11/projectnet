﻿using System;
using Microsoft.AspNetCore.Mvc;
using Webthucannhanh.Datas;

namespace Webthucannhanh.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GuestsController : ControllerBase
    {
        private readonly FoodOrderingDbContext _context;

        public GuestsController(FoodOrderingDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var guests = _context.Guests.ToList();
            return Ok(guests);
        }

        [HttpPost]
        public IActionResult Create(Guest guest)
        {
            _context.Guests.Add(guest);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetById), new { id = guest.GuestId }, guest);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var guest = _context.Guests.Find(id);
            if (guest == null)
            {
                return NotFound();
            }
            return Ok(guest);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var guest = _context.Guests.Find(id);
            if (guest == null)
            {
                return NotFound();
            }

            _context.Guests.Remove(guest);
            _context.SaveChanges();
            return NoContent();
        }
    }

}



