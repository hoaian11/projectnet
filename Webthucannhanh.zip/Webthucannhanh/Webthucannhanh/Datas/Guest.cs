﻿using System.ComponentModel.DataAnnotations;

namespace Webthucannhanh.Datas
{
    public class Guest
    {
        [Key]
        public int GuestId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
