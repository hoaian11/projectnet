﻿using Microsoft.EntityFrameworkCore;

namespace Webthucannhanh.Datas
{
    public class FoodOrderingDbContext : DbContext
    {
        public FoodOrderingDbContext(DbContextOptions<FoodOrderingDbContext> options) : base(options)
        {
        }

        public DbSet<Guest> Guests { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<FoodItem> FoodItems { get; set; }
        public DbSet<Combo> Combos { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<ComboDetail> ComboDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

       => optionsBuilder.UseSqlServer("Server = localhost,1433; Database=FoodOrderingDB;User Id = sa; Password=Password.1;TrustServerCertificate=True");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OrderDetail>()
                .HasKey(od => od.OrderDetailId);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.Order)
                .WithMany(o => o.OrderDetails)
                .HasForeignKey(od => od.OrderId);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.FoodItem)
                .WithMany(fi => fi.OrderDetails)
                .HasForeignKey(od => od.FoodItemId);

            modelBuilder.Entity<ComboDetail>()
                .HasKey(cd => cd.ComboDetailId);

            modelBuilder.Entity<ComboDetail>()
                .HasOne(cd => cd.Combo)
                .WithMany(c => c.ComboDetails)
                .HasForeignKey(cd => cd.ComboId);

            modelBuilder.Entity<ComboDetail>()
                .HasOne(cd => cd.FoodItem)
                .WithMany(fi => fi.ComboDetails)
                .HasForeignKey(cd => cd.FoodItemId);

            // Các cấu hình bổ sung khác (nếu có)...
        }
    }
}
