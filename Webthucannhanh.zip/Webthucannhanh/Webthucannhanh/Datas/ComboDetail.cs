﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Webthucannhanh.Datas
{
    public class ComboDetail
    {
        [Key]
        public int ComboDetailId { get; set; }

        [ForeignKey("Combo")]
        public int ComboId { get; set; }

        [ForeignKey("FoodItem")]
        public int FoodItemId { get; set; }
        public int Quantity { get; set; }

        public Combo Combo { get; set; }
        public FoodItem FoodItem { get; set; }
    }
}
